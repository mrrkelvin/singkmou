# DEPRECATED

Use the [Ionic Cloud Client](https://github.com/driftyco/ionic-cloud).

* [Setup/Installation](http://docs.ionic.io/setup.html).
* [Migration Guide](http://docs.ionic.io/migration.html) (from
  `ionic-platform-web-client` to Ionic Cloud Client).
